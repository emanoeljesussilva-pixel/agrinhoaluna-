import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client Lazily to prevent startup crashes if GEMINI_API_KEY is missing
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// API Route: SEAB & IDR-Paraná data simulator for Iretama, PR
app.get("/api/seab-idr", (req, res) => {
  // Mocking real-time Paraná agricultural index and weather data
  res.json({
    timestamp: new Date().toISOString(),
    weather: {
      location: "Iretama, PR",
      temperature: 24.5,
      humidity: 78,
      precipitationProb: "15%",
      condition: "Parcialmente Nublado",
      windSpeed: "12 km/h",
      climatologySource: "IDR-Paraná (Simepar)",
      bulletin: "Condições ideais para aplicação de bioinsumos via drones nesta tarde. Ventos abaixo de 15 km/h garantem deriva mínima.",
    },
    prices: {
      source: "SEAB-PR / DERAL",
      region: "Campo Mourão / Iretama",
      crops: [
        { name: "Soja (Saca 60kg)", price: 135.50, change: "+0.45%", trend: "up" },
        { name: "Milho (Saca 60kg)", price: 58.20, change: "-0.15%", trend: "down" },
        { name: "Trigo (Saca 60kg)", price: 72.80, change: "0.00%", trend: "stable" },
        { name: "Café Cereja Descascado (Saca 60kg)", price: 1120.00, change: "+1.20%", trend: "up" },
        { name: "Mandioca (Tonelada posta indústria)", price: 410.00, change: "+0.80%", trend: "up" },
      ]
    }
  });
});

// API Route: IBGE indicators for Iretama, PR
app.get("/api/ibge", (req, res) => {
  res.json({
    location: "Iretama - PR",
    code: "4110603",
    indicators: [
      { category: "População", label: "População Residente (Censo 2022)", value: "10.029 hab.", source: "IBGE 2022" },
      { category: "Socioeconômico", label: "PIB per capita", value: "R$ 38.412,90", source: "IBGE 2021" },
      { category: "Socioeconômico", label: "IDHM (Índice de Desenvolvimento Humano)", value: "0,686 (Médio)", source: "IBGE / PNUD" },
      { category: "Produção Agrícola", label: "Área de Lavoura Temporária", value: "32.400 hectares", source: "IBGE PAM" },
      { category: "Produção Agrícola", label: "Valor da Produção Agrícola", value: "R$ 214 Milhões", source: "IBGE PAM" },
      { category: "Socioeconômico", label: "Pessoal ocupado no Agro", value: "42.8% da pop. ativa", source: "IBGE Censo Agro" },
    ],
    marketDemand: {
      summary: "Alta demanda por produtos com rastreabilidade de origem (soja e café de Iretama). Crescimento do interesse em biocombustíveis e grãos com certificação de pegada de carbono zero no mercado internacional.",
      regionalTrend: "A região de Iretama possui forte presença de agricultura familiar e cooperativismo (Coamo). Há um espaço emergente para a mecanização inteligente de encostas onduladas e automação de baixo custo."
    }
  });
});

// API Route: AI Advisor (Gemini)
app.post("/api/gemini/advisor", async (req, res) => {
  const { message, systemMode, contextData } = req.body;
  
  if (!message) {
    return res.status(400).json({ error: "Mensagem é obrigatória." });
  }

  const ai = getGeminiClient();

  // If Gemini client is unavailable, return a highly informative local rule-based system
  if (!ai) {
    console.log("Gemini API Key missing or default. Emulating local expert advice.");
    return res.json({
      text: getFallbackAdvisorResponse(message, systemMode, contextData),
      emulated: true
    });
  }

  try {
    const defaultInstruction = `Você é o AgroIretamaGPT, um engenheiro agrônomo especialista em agricultura digital, sustentabilidade e tecnologias de precisão, focado na região de Iretama, Paraná.
Você auxilia pequenos e grandes produtores rurais a otimizar colheitas, analisar sensores de solo, interpretar dados do IDR-Paraná e SEAB, realizar transações rastreáveis via blockchain e gerar relatórios de impacto ambiental.

Sua postura é prestativa, técnica e focada em sustentabilidade (plantio direto, redução de químicos, economia de água, integração lavoura-pecuária-floresta).
Sempre responda em português do Brasil de forma clara, organizada com tópicos e altamente acessível.

Contexto atual fornecido pelo usuário: ${JSON.stringify(contextData || {})}
Modo solicitado: ${systemMode || "geral"}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: message,
      config: {
        systemInstruction: defaultInstruction,
        temperature: 0.7,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Erro na API Gemini:", error);
    res.status(500).json({ 
      error: "Erro ao processar requisição de inteligência artificial.", 
      details: error.message,
      fallback: getFallbackAdvisorResponse(message, systemMode, contextData)
    });
  }
});

// Fallback response engine for when Gemini key is absent, so the application is ALWAYS fully functional!
function getFallbackAdvisorResponse(message: string, systemMode: string, contextData: any): string {
  const query = message.toLowerCase();
  
  if (systemMode === "translate") {
    return `[Tradução Assistida local] Seu texto: "${message}" foi processado. Para traduções customizadas em tempo real, configure sua chave do Gemini nos Secrets. Nosso widget de acessibilidade possui dicionário multilíngue estático completo com traduções instantâneas de alta qualidade para Inglês, Espanhol e Linguagem Simplificada!`;
  }

  if (query.includes("solo") || query.includes("sensor") || query.includes("umidade") || query.includes("ph")) {
    const moisture = contextData?.moisture ?? 35;
    const ph = contextData?.ph ?? 6.2;
    const nitrogen = contextData?.nitrogen ?? 45;
    
    return `### 🌾 Diagnóstico Inteligente de Solo para Iretama/PR:
    
Suas leituras de sensores mostram atualmente: **Umidade: ${moisture}%**, **pH: ${ph}** e **Nitrogênio: ${nitrogen} mg/kg**.

1. **Análise de pH (${ph}):** O solo de Iretama situa-se em uma zona de transição típica do planalto de Campo Mourão. Um pH de ${ph} é ligeiramente ácido a neutro, excelente para soja e milho. Caso o pH caia abaixo de 5.5, recomendamos a aplicação de calcário agrícola por calagem superficial em sistema de plantio direto.
2. **Recomendação Hídrica (${moisture}%):** 
   - Se estiver abaixo de 30%: Ative o gotejamento programado de precisão.
   - Se estiver entre 30% e 55%: Nível ideal para o desenvolvimento radicular.
   - Se estiver acima de 60%: Risco de saturação em solos argilosos de Iretama. Suspenda a irrigação.
3. **Nutrientes NPK:** O nitrogênio está em nível ${nitrogen < 40 ? "crítico" : "adequado"}. Recomendamos rotação de culturas com leguminosas (como crotalária ou feijão de porco) para fixação biológica de nitrogênio, em vez de fertilizantes nitrogenados sintéticos de alta pegada de carbono.`;
  }

  if (query.includes("colheita") || query.includes("automação") || query.includes("drone")) {
    return `### 🛰️ Automação de Colheita Sustentável em Iretama:

A topografia ondulada de Iretama exige planejamento de tráfego de máquinas para evitar a compactação do solo e a erosão pluvial:
1. **Drones com IA (Multiespectrais):** Mapeiam reboleiras de plantas daninhas antes da colheita. Permitem aplicação localizada de bioinsumos (deriva controlada, economia de 90% em químicos).
2. **Colheitadeiras Autônomas:** Configuração de piloto automático com georreferenciamento RTK. A colheita deve ser feita em curvas de nível, respeitando o terraciamento de Iretama para reter a água das chuvas.
3. **Sensores Ópticos:** Monitoramento em tempo real do teor de impurezas e umidade dos grãos na moega, otimizando o gasto energético na secagem pós-colheita.`;
  }

  if (query.includes("blockchain") || query.includes("pagamento") || query.includes("rastreabilidade")) {
    return `### ⛓️ Rastreabilidade e Blockchain no Agro de Iretama:

A tecnologia blockchain atua como um cartório digital inviolável para os lotes agrícolas:
1. **Transparência de Origem:** Cada lote de soja ou café colhido em Iretama recebe um QR Code amarrado a uma transação criptográfica.
2. **Dados Gravados:** São salvos em ledger público as coordenadas da fazenda, laudo do CAR, ausência de desmatamento ilegal e emissões de carbono calculadas.
3. **Pagamento Seguro:** Com contratos inteligentes (Smart Contracts), o produtor recebe o pagamento instantaneamente na carteira digital assim que a transportadora valida a entrega física no porto de Paranaguá, reduzindo intermediários e tarifas bancárias.`;
  }

  if (query.includes("iretama") || query.includes("parana") || query.includes("região")) {
    return `### 🌲 Agricultura de Precisão na Região de Iretama/PR:

Iretama destaca-se pelo relevo ondulado e rica hidrografia (região turística de águas termais). 
- **Desafio:** A declividade de algumas áreas exige o manejo conservacionista rígido.
- **Tecnologias de Ponta Recomendadas:** Integração Lavoura-Pecuária-Floresta (ILPF) para proteção de encostas, uso de pastagens ecológicas de capim tifton para bacia leiteira, e sensores de monitoramento de microbacias para evitar contaminação de águas por fertilizantes.
- **Parcerias Locais:** O IDR-Paraná (unidade local) e as cooperativas regionais oferecem assistência para a transição agroecológica e certificações orgânicas de café de montanha.`;
  }

  return `### 🌱 Olá! Sou o AgroIretamaGPT, seu Consultor Agrícola de Precisão.

Pergunte-me sobre:
- **Sensores de Solo:** Como otimizar a umidade e nutrientes para soja ou café.
- **Mecanização e Automação:** Drones, satélites, robôs agrícolas sustentáveis em Iretama.
- **Relatório de Impacto:** Como quantificar o CO2 sequestrado ou a água poupada.
- **Sistemas do Governo (IDR-PR, SEAB, IBGE):** Preços atuais, clima ou indicadores da região.
- **Blockchain:** Como funciona a rastreabilidade e contratos inteligentes do lote de grãos.

*Nota: Para respostas customizadas avançadas geradas por inteligência artificial em tempo real, configure a GEMINI_API_KEY no menu Secrets do AI Studio.*`;
}

// API Route: Blockchain Traceability simulator
app.get("/api/blockchain/trace", (req, res) => {
  res.json({
    activeBatches: [
      {
        id: "IRT-SOJA-2026-004",
        product: "Soja Intacta Sustentável Rastreável",
        origin: "Fazenda Cultivando Futuro - Iretama, PR",
        producer: "Cooperativa AgroIretama",
        harvestDate: "2026-06-15",
        tonnes: 45.0,
        carbonFootprint: "0.12 kg CO2e / kg",
        pesticideReduction: "85% (Defensivos Biológicos)",
        waterEfficiency: "+40% de retenção no solo",
        soilPH: 6.2,
        carCertificate: "PR-4110603-9F93.D4C8.910E",
        blockchainHash: "0x7f4e9a3b8c2d1e0f93a2c5d6e8f901234a5b6c7d",
        status: "Certificado e Rastreável (Ledger Ativo)",
        ipfsMetadata: "ipfs://QmYwAPzwh3pVWg8e329B127ic6JnH31A384A9g8c"
      },
      {
        id: "IRT-CAFE-2026-012",
        product: "Café Especial de Montanha Iretama",
        origin: "Sítio Águas Termais - Iretama, PR",
        producer: "Associação de Produtores Familiares de Iretama",
        harvestDate: "2026-06-18",
        tonnes: 3.5,
        carbonFootprint: "-0.08 kg CO2e / kg (Carbono Negativo)",
        pesticideReduction: "100% Orgânico Certificado",
        waterEfficiency: "Irrigação por gotejamento solar",
        soilPH: 5.9,
        carCertificate: "PR-4110603-2E11.A3F4.1102",
        blockchainHash: "0x3c9a2d8e4f1b0c9a7d3f5e9b8c6a2e1d0f8a7c5b",
        status: "Certificado e Rastreável (Ledger Ativo)",
        ipfsMetadata: "ipfs://QmXzTRr8P71bCw6d71As89P1cWq30Aa529B9c2d"
      }
    ]
  });
});

// Vite Middleware & Static File serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[FULL-STACK] Servidor rodando em http://localhost:${PORT}`);
  });
}

startServer();
