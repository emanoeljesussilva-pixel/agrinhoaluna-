import React, { useState, useEffect } from "react";
import { TraceableBatch } from "../types";
import { Link2, ShieldCheck, Check, DollarSign, RefreshCw, QrCode } from "lucide-react";

interface BlockchainLedgerProps {
  langKeys: Record<string, string>;
  isHighContrast: boolean;
}

export const BlockchainLedger: React.FC<BlockchainLedgerProps> = ({
  langKeys,
  isHighContrast,
}) => {
  const [batches, setBatches] = useState<TraceableBatch[]>([]);
  const [selectedBatch, setSelectedBatch] = useState<TraceableBatch | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [paymentLoading, setPaymentLoading] = useState<boolean>(false);
  const [paymentSuccess, setPaymentSuccess] = useState<string | null>(null);
  const [simulatedBlock, setSimulatedBlock] = useState<number>(1984201);

  // Fetch from our backend express route for traceability!
  useEffect(() => {
    fetch("/api/blockchain/trace")
      .then((res) => {
        if (!res.ok) throw new Error("Erro de rede");
        return res.json();
      })
      .then((data) => {
        setBatches(data.activeBatches || []);
        if (data.activeBatches && data.activeBatches.length > 0) {
          setSelectedBatch(data.activeBatches[0]);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.warn("AgroTech: Carregando fallback blockchain estático local devido a ambiente cliente do vscode.dev:", err);
        const fallbackBatches: TraceableBatch[] = [
          {
            id: "LOT-2026-SOJA-04",
            product: "Soja Intacta 2X PRO Sustentável",
            producer: "Cooperativa Agropecuária Iretama",
            origin: "Fazenda Água Clara, Iretama - PR",
            harvestDate: "2026-05-12",
            tonnes: 120,
            carbonFootprint: "-0.24 t CO2e/t",
            pesticideReduction: "Redução de 45% (Controle Biológico)",
            waterEfficiency: "92% (Gotejamento micro-localizado)",
            soilPH: 6.2,
            carCertificate: "PR-4110606-8D3A.11E9.8C5C.2234B543",
            status: "certificado",
            blockchainHash: "0x8fa176df912b7405c938eeff28c0b4317f2e51921c3b1ea08d27464fe9a128df",
            ipfsMetadata: "ipfs://QmXGTyGz3vNf4D8eK86V3Lp11R2A4b6s17C9y9j82P8t5U",
          },
          {
            id: "LOT-2026-CAFE-08",
            product: "Café Especial de Montanha Orgânico",
            producer: "Sítio das Palmeiras, Iretama",
            origin: "Serra de Iretama, PR - Altitude: 840m",
            harvestDate: "2026-06-02",
            tonnes: 45,
            carbonFootprint: "-1.12 t CO2e/t",
            pesticideReduction: "Livre de Defensivos (100% Orgânico)",
            waterEfficiency: "96% (Captação pluvial integrada)",
            soilPH: 6.0,
            carCertificate: "PR-4110606-AC92.34F8.11EE.BB82.88219AA1",
            status: "certificado",
            blockchainHash: "0x5c42eeaa8a0b0f498c82348ff98a127f8d68d183e91d848bc29dfef111eeaa8f",
            ipfsMetadata: "ipfs://QmY8m4C1V3n8s7GzZc8L9p2R5P6n8W4T2Y7m5X1R2P3q4N",
          },
          {
            id: "LOT-2026-MILH-02",
            product: "Milho Safrinha Consorciado de Carbono",
            producer: "Agropecuária Rio Jordão, Iretama",
            origin: "Vale do Rio Jordão, Iretama - PR",
            harvestDate: "2026-05-28",
            tonnes: 85,
            carbonFootprint: "-0.08 t CO2e/t",
            pesticideReduction: "Redução de 30% (Rotação Integrada)",
            waterEfficiency: "88% (Sequeiro Monitorado)",
            soilPH: 6.3,
            carCertificate: "PR-4110606-B81D.22C1.99FA.443E.332A8F91",
            status: "certificado",
            blockchainHash: "0x918aa72efd71ca18ef612c62c2f718bc321c82ee331ffca28bc72de51221ac19",
            ipfsMetadata: "ipfs://QmZ11P5mR3t8S7H9X8V7D6k5L4j3K2H1g7f8e9d0c2b1a",
          }
        ];
        setBatches(fallbackBatches);
        setSelectedBatch(fallbackBatches[0]);
        setLoading(false);
      });
  }, []);

  const triggerPayment = (batchId: string) => {
    setPaymentLoading(true);
    setPaymentSuccess(null);
    setTimeout(() => {
      setPaymentLoading(false);
      setPaymentSuccess(batchId);
      setSimulatedBlock((prev) => prev + 1);
    }, 2000);
  };

  if (loading) {
    return (
      <div className="p-6 bg-white dark:bg-zinc-800 rounded-2xl border border-slate-200 text-center">
        <RefreshCw className="w-8 h-8 text-green-700 animate-spin mx-auto mb-2" />
        <p className="text-sm font-semibold text-slate-600">Conectando ao nó AgroChain...</p>
      </div>
    );
  }

  return (
    <section
      id="blockchain"
      className="p-6 bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl shadow-lg transition-all"
      aria-labelledby="blockchain-title-id"
    >
      <div className="flex items-center justify-between flex-wrap gap-4 mb-2">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-8 h-8 text-green-700 dark:text-green-500" />
          <h2 id="blockchain-title-id" className="text-2xl font-bold text-slate-800 dark:text-white">
            {langKeys["trace.title"]}
          </h2>
        </div>
        <div className="text-xs bg-slate-100 dark:bg-zinc-900 px-3 py-1 rounded-full text-slate-500 dark:text-zinc-400 font-mono">
          Nó Ativo: <span className="text-green-600 font-bold">#PR-Iretama-01</span> | Bloco Atual: <span className="font-bold">{simulatedBlock}</span>
        </div>
      </div>
      <p className="text-sm text-slate-500 dark:text-zinc-400 mb-6">
        {langKeys["trace.subtitle"]}
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Lista de Lotes Certificados */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-500 dark:text-zinc-400 uppercase tracking-wider mb-2">
            Lotes Ativos na Safra
          </h3>
          {batches.map((b) => (
            <button
              key={b.id}
              onClick={() => {
                setSelectedBatch(b);
                setPaymentSuccess(null);
              }}
              className={`w-full p-4 rounded-xl text-left border-2 transition-all flex items-center justify-between cursor-pointer ${
                selectedBatch?.id === b.id
                  ? "border-green-600 bg-green-50/50 dark:bg-zinc-900/40"
                  : "border-slate-200 dark:border-zinc-700 hover:border-slate-300 dark:hover:border-zinc-600 bg-white dark:bg-zinc-900"
              }`}
            >
              <div>
                <span className="text-xs font-semibold text-slate-500 font-mono block">
                  {b.id}
                </span>
                <span className="font-bold text-slate-800 dark:text-white text-sm block">
                  {b.product}
                </span>
                <span className="text-[10px] text-green-700 dark:text-green-400 block font-semibold mt-1">
                  {b.producer}
                </span>
              </div>
              <ShieldCheck className={`w-5 h-5 ${selectedBatch?.id === b.id ? "text-green-600" : "text-slate-300"}`} />
            </button>
          ))}
        </div>

        {/* Detalhes de Rastreabilidade */}
        {selectedBatch && (
          <div className="lg:col-span-2 p-5 bg-slate-50 dark:bg-zinc-900/30 border border-slate-200 dark:border-zinc-700 rounded-xl">
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-xs font-mono bg-green-100 dark:bg-green-950/40 text-green-800 dark:text-green-300 py-0.5 px-2 rounded font-bold">
                  {selectedBatch.status}
                </span>
                <h3 className="text-xl font-extrabold text-slate-800 dark:text-white mt-1.5">
                  {selectedBatch.product}
                </h3>
              </div>
              
              {/* QR Code Simulado */}
              <div className="p-1 bg-white dark:bg-zinc-800 border border-slate-300 rounded-md shadow-sm flex flex-col items-center">
                <QrCode className="w-14 h-14 text-slate-800 dark:text-white" />
                <span className="text-[8px] text-slate-400 mt-0.5 font-mono">Scan Origem</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-6">
              <div>
                <span className="text-xs text-slate-500 block">{langKeys["trace.origin"]}</span>
                <strong className="text-slate-800 dark:text-white">{selectedBatch.origin}</strong>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">{langKeys["trace.producer"]}</span>
                <strong className="text-slate-800 dark:text-white">{selectedBatch.producer}</strong>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">{langKeys["trace.date"]}</span>
                <strong className="text-slate-800 dark:text-white font-mono">{selectedBatch.harvestDate}</strong>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">{langKeys["trace.carbon"]}</span>
                <strong className="text-green-700 dark:text-green-400 font-mono">{selectedBatch.carbonFootprint}</strong>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">{langKeys["trace.pesticide"]}</span>
                <strong className="text-slate-800 dark:text-white">{selectedBatch.pesticideReduction}</strong>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Certificação CAR:</span>
                <strong className="text-slate-800 dark:text-white font-mono text-xs">{selectedBatch.carCertificate}</strong>
              </div>
            </div>

            <div className="p-3 bg-slate-100 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-lg mb-6 text-xs space-y-2">
              <div className="flex items-center gap-1.5 text-slate-500">
                <Link2 className="w-3.5 h-3.5 text-green-700" />
                <span>{langKeys["trace.hash"]}</span>
              </div>
              <p className="font-mono text-slate-700 dark:text-zinc-300 truncate font-semibold">
                {selectedBatch.blockchainHash}
              </p>
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>Metadados IPFS: {selectedBatch.ipfsMetadata}</span>
                <span>Certificado pelo Código Florestal e Embrapa</span>
              </div>
            </div>

            {/* Ação de Pagamento Smart Contract */}
            <div>
              <button
                onClick={() => triggerPayment(selectedBatch.id)}
                disabled={paymentLoading || paymentSuccess === selectedBatch.id}
                className={`w-full py-3 px-6 font-bold text-base rounded-xl shadow flex items-center justify-center gap-2 transition-all ${
                  paymentSuccess === selectedBatch.id
                    ? "bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300 border border-green-300 cursor-default"
                    : "bg-green-700 text-white hover:bg-green-600 hover:-translate-y-0.5 cursor-pointer"
                }`}
              >
                {paymentLoading ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Processando Contrato Inteligente...</span>
                  </>
                ) : paymentSuccess === selectedBatch.id ? (
                  <>
                    <Check className="w-5 h-5 text-green-700 dark:text-green-400" />
                    <span>{langKeys["trace.pay.success"]}</span>
                  </>
                ) : (
                  <>
                    <DollarSign className="w-5 h-5" />
                    <span>{langKeys["trace.pay.btn"]}</span>
                  </>
                )}
              </button>
              {paymentSuccess === selectedBatch.id && (
                <p className="text-center text-xs text-green-600 dark:text-green-500 font-bold mt-2 font-mono">
                  Bloco #{simulatedBlock} minerado com sucesso. Hash do comprovante: 0x9f2a...{selectedBatch.id.slice(-3)}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
