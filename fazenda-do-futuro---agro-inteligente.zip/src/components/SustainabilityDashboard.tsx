import React, { useState } from "react";
import { EnvironmentalReport } from "../types";
import { BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { LayoutDashboard, Calendar, FileDown, Check, TrendingUp } from "lucide-react";

interface SustainabilityDashboardProps {
  langKeys: Record<string, string>;
  isHighContrast: boolean;
}

const mockReportData: EnvironmentalReport[] = [
  { month: "Jan", co2Captured: 12.4, waterSaved: 340, chemicalAvoided: 180, soilHealthIndex: 78, biodiversityScore: 72 },
  { month: "Fev", co2Captured: 14.8, waterSaved: 390, chemicalAvoided: 220, soilHealthIndex: 80, biodiversityScore: 74 },
  { month: "Mar", co2Captured: 16.2, waterSaved: 420, chemicalAvoided: 260, soilHealthIndex: 82, biodiversityScore: 76 },
  { month: "Abr", co2Captured: 18.5, waterSaved: 480, chemicalAvoided: 310, soilHealthIndex: 85, biodiversityScore: 79 },
  { month: "Mai", co2Captured: 21.1, waterSaved: 540, chemicalAvoided: 380, soilHealthIndex: 88, biodiversityScore: 82 },
  { month: "Jun", co2Captured: 24.3, waterSaved: 610, chemicalAvoided: 450, soilHealthIndex: 92, biodiversityScore: 86 },
];

export const SustainabilityDashboard: React.FC<SustainabilityDashboardProps> = ({
  langKeys,
  isHighContrast,
}) => {
  const [selectedMonth, setSelectedMonth] = useState<string>("Jun");
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportSuccess, setExportSuccess] = useState<boolean>(false);

  const activeData = mockReportData.find((d) => d.month === selectedMonth) || mockReportData[5];

  const handleExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 4000);
    }, 1500);
  };

  // Define color palettes based on Contrast settings for WCAG alignment
  const colorPrimary = isHighContrast ? "#FBBF24" : "#16A34A"; // Yellow vs Green
  const colorSecondary = isHighContrast ? "#00FFFF" : "#0D9488"; // Cyan vs Teal
  const colorAlert = isHighContrast ? "#FFFFFF" : "#DC2626"; // White vs Red

  return (
    <section
      id="dashboard"
      className="p-6 bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl shadow-lg transition-all"
      aria-labelledby="dashboard-title-id"
    >
      <div className="flex items-center justify-between flex-wrap gap-4 mb-2">
        <div className="flex items-center gap-3">
          <LayoutDashboard className="w-8 h-8 text-green-700 dark:text-green-500" />
          <h2 id="dashboard-title-id" className="text-2xl font-bold text-slate-800 dark:text-white">
            {langKeys["db.title"]}
          </h2>
        </div>
        
        {/* Filtro Mensal */}
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-slate-500" />
          <label htmlFor="select-month" className="text-sm font-semibold text-slate-600 dark:text-zinc-300">
            Filtrar Mês:
          </label>
          <select
            id="select-month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="text-sm border border-slate-300 dark:border-zinc-700 rounded-lg py-1 px-3 bg-white dark:bg-zinc-900 text-slate-800 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-green-600"
          >
            {mockReportData.map((d) => (
              <option key={d.month} value={d.month}>
                2026 - {d.month}
              </option>
            ))}
          </select>
        </div>
      </div>
      <p className="text-sm text-slate-500 dark:text-zinc-400 mb-8">
        {langKeys["db.subtitle"]}
      </p>

      {/* Grid de Métricas Principais */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="p-4 bg-green-50 dark:bg-zinc-900/40 rounded-xl border border-green-100 dark:border-zinc-800 text-center">
          <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 block mb-1">
            {langKeys["db.metric1"]}
          </span>
          <span className="text-2xl font-extrabold text-green-700 dark:text-green-400 block font-mono">
            {activeData.co2Captured} t
          </span>
          <span className="text-[10px] text-green-600 dark:text-green-500 mt-1 block">
            🍃 Sequestro Ativo
          </span>
        </div>

        <div className="p-4 bg-teal-50 dark:bg-zinc-900/40 rounded-xl border border-teal-100 dark:border-zinc-800 text-center">
          <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 block mb-1">
            {langKeys["db.metric2"]}
          </span>
          <span className="text-2xl font-extrabold text-teal-700 dark:text-teal-400 block font-mono">
            {activeData.waterSaved}K L
          </span>
          <span className="text-[10px] text-teal-600 dark:text-teal-500 mt-1 block">
            💧 Economia Hídrica
          </span>
        </div>

        <div className="p-4 bg-amber-50 dark:bg-zinc-900/40 rounded-xl border border-amber-100 dark:border-zinc-800 text-center">
          <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 block mb-1">
            {langKeys["db.metric3"]}
          </span>
          <span className="text-2xl font-extrabold text-amber-700 dark:text-amber-400 block font-mono">
            {activeData.chemicalAvoided} kg
          </span>
          <span className="text-[10px] text-amber-600 dark:text-amber-500 mt-1 block">
            🐝 Insumos Biológicos
          </span>
        </div>

        <div className="p-4 bg-blue-50 dark:bg-zinc-900/40 rounded-xl border border-blue-100 dark:border-zinc-800 text-center">
          <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 block mb-1">
            {langKeys["db.metric4"]}
          </span>
          <span className="text-2xl font-extrabold text-blue-700 dark:text-blue-400 block font-mono">
            {activeData.soilHealthIndex}/100
          </span>
          <span className="text-[10px] text-blue-600 dark:text-blue-500 mt-1 block">
            🌱 Regeneração Biológica
          </span>
        </div>
      </div>

      {/* Gráficos Recharts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-6">
        {/* Gráfico 1 - Área */}
        <div className="p-4 border border-slate-200 dark:border-zinc-700 rounded-xl bg-slate-50 dark:bg-zinc-900/20">
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-green-600" /> {langKeys["db.chart1"]}
          </h3>
          <div className="h-64" role="img" aria-label="Gráfico de Área demonstrando o crescimento mensal de CO2 e Água Poupada.">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockReportData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="month" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="co2Captured"
                  name="Carbono Sequestrado (t)"
                  stroke={colorPrimary}
                  fill={colorPrimary}
                  fillOpacity={0.15}
                />
                <Area
                  type="monotone"
                  dataKey="waterSaved"
                  name="Água Salva (m³)"
                  stroke={colorSecondary}
                  fill={colorSecondary}
                  fillOpacity={0.1}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Gráfico 2 - Barras */}
        <div className="p-4 border border-slate-200 dark:border-zinc-700 rounded-xl bg-slate-50 dark:bg-zinc-900/20">
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-teal-600" /> {langKeys["db.chart2"]}
          </h3>
          <div className="h-64" role="img" aria-label="Gráfico de Barras demonstrando quilos de defensivos químicos sintéticos evitados mensalmente.">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockReportData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="month" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Legend />
                <Bar
                  dataKey="chemicalAvoided"
                  name="Defensivos Evitados (kg)"
                  fill={colorPrimary}
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="biodiversityScore"
                  name="Índice de Biodiversidade"
                  fill={colorSecondary}
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Relatório Mensal Exportável */}
      <div className="p-5 bg-green-50/50 dark:bg-zinc-900/40 border border-green-200 dark:border-zinc-700 rounded-xl flex items-center justify-between flex-wrap gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-1">
            {langKeys["db.report.title"]} - Mês de {activeData.month}
          </h3>
          <p className="text-xs text-slate-600 dark:text-zinc-400 max-w-xl">
            Este relatório consolida os dados de IoT, Drones e Blockchain relativos ao mês de {activeData.month}/2026. Documento certificado e registrado em blockchain pública, livre de desmatamento ilegal.
          </p>
        </div>

        <div className="flex flex-col sm:items-end gap-1.5">
          <button
            onClick={handleExport}
            disabled={isExporting}
            className={`py-2 px-5 font-bold rounded-lg shadow text-sm flex items-center gap-2 transition-all ${
              isExporting
                ? "bg-slate-300 text-slate-600 cursor-not-allowed"
                : "bg-green-700 text-white hover:bg-green-600 cursor-pointer"
            }`}
          >
            <FileDown className="w-4 h-4" />
            {isExporting ? "Exportando..." : langKeys["db.report.btn"]}
          </button>
          {exportSuccess && (
            <span className="text-xs text-green-700 dark:text-green-400 flex items-center gap-1 font-semibold">
              <Check className="w-3.5 h-3.5" /> PDF/CSV gerado e salvo em downloads!
            </span>
          )}
        </div>
      </div>
    </section>
  );
};
