import React from "react";
import { AccessibilitySettings } from "../types";
import { Eye, Type, BookOpen, Volume2, HelpCircle, Monitor } from "lucide-react";

interface AccessibilityPanelProps {
  settings: AccessibilitySettings;
  setSettings: React.Dispatch<React.SetStateAction<AccessibilitySettings>>;
  onAnnounce: (msg: string) => void;
  langKeys: Record<string, string>;
}

export const AccessibilityPanel: React.FC<AccessibilityPanelProps> = ({
  settings,
  setSettings,
  onAnnounce,
  langKeys,
}) => {
  const toggleContrast = () => {
    setSettings((prev) => {
      const newVal = !prev.highContrast;
      onAnnounce(newVal ? "Modo de alto contraste ativado" : "Modo de alto contraste desativado");
      return { ...prev, highContrast: newVal };
    });
  };

  const toggleDyslexia = () => {
    setSettings((prev) => {
      const newVal = !prev.dyslexicFont;
      onAnnounce(newVal ? "Fonte acessível para dislexia ativada" : "Fonte para dislexia desativada");
      return { ...prev, dyslexicFont: newVal };
    });
  };

  const toggleReadingLine = () => {
    setSettings((prev) => {
      const newVal = !prev.readingLine;
      onAnnounce(newVal ? "Guia de linha de leitura ativada" : "Guia de linha de leitura desativada");
      return { ...prev, readingLine: newVal };
    });
  };

  const toggleMonochrome = () => {
    setSettings((prev) => {
      const newVal = !prev.monochrome;
      onAnnounce(newVal ? "Modo monocromático ativado" : "Modo monocromático desativado");
      return { ...prev, monochrome: newVal };
    });
  };

  const changeFontSize = (size: AccessibilitySettings["fontSize"]) => {
    setSettings((prev) => {
      onAnnounce(`Tamanho de fonte alterado para ${size}`);
      return { ...prev, fontSize: size };
    });
  };

  return (
    <section
      id="acessibilidade"
      className="p-6 bg-slate-100 dark:bg-zinc-900 border-2 border-green-600 rounded-2xl shadow-xl transition-all duration-300"
      aria-labelledby="a11y-heading"
    >
      <div className="flex items-center gap-3 mb-4">
        <Eye className="w-8 h-8 text-green-700 dark:text-green-500" aria-hidden="true" />
        <h2 id="a11y-heading" className="text-2xl font-bold text-slate-800 dark:text-slate-100">
          {langKeys["a11y.panel"]}
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Controles Visuais */}
        <div className="p-4 bg-white dark:bg-zinc-800 rounded-xl border border-slate-300 dark:border-zinc-700">
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-green-700 dark:text-green-400">
            <Monitor className="w-5 h-5" /> Opções de Visualização
          </h3>
          <div className="space-y-3">
            <button
              onClick={toggleContrast}
              id="btn-high-contrast"
              className={`w-full py-2.5 px-4 rounded-lg font-bold transition-all text-sm flex items-center justify-between border-2 ${
                settings.highContrast
                  ? "bg-yellow-400 text-black border-yellow-500 hover:bg-yellow-300"
                  : "bg-slate-200 dark:bg-zinc-700 text-slate-800 dark:text-white border-transparent hover:bg-slate-300 dark:hover:bg-zinc-600"
              }`}
              aria-pressed={settings.highContrast}
            >
              <span>{langKeys["a11y.highcontrast"]}</span>
              <span className="text-xs font-mono uppercase bg-slate-400/20 px-2 py-0.5 rounded">
                {settings.highContrast ? "Ativo" : "Inativo"}
              </span>
            </button>

            <button
              onClick={toggleMonochrome}
              id="btn-monochrome"
              className={`w-full py-2.5 px-4 rounded-lg font-bold transition-all text-sm flex items-center justify-between border-2 ${
                settings.monochrome
                  ? "bg-slate-800 text-white dark:bg-white dark:text-black border-slate-900 hover:opacity-90"
                  : "bg-slate-200 dark:bg-zinc-700 text-slate-800 dark:text-white border-transparent hover:bg-slate-300 dark:hover:bg-zinc-600"
              }`}
              aria-pressed={settings.monochrome}
            >
              <span>{langKeys["a11y.monochrome"]}</span>
              <span className="text-xs font-mono uppercase bg-slate-400/20 px-2 py-0.5 rounded">
                {settings.monochrome ? "Ativo" : "Inativo"}
              </span>
            </button>
          </div>
        </div>

        {/* Tipografia */}
        <div className="p-4 bg-white dark:bg-zinc-800 rounded-xl border border-slate-300 dark:border-zinc-700">
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-green-700 dark:text-green-400">
            <Type className="w-5 h-5" /> {langKeys["a11y.fontsize"]}
          </h3>
          <div className="flex gap-2 mb-4" role="group" aria-label="Tamanhos de letra">
            {(["sm", "base", "lg", "xl"] as AccessibilitySettings["fontSize"][]).map((size) => (
              <button
                key={size}
                onClick={() => changeFontSize(size)}
                className={`flex-1 py-1.5 px-2 rounded-md font-bold text-sm border transition-all ${
                  settings.fontSize === size
                    ? "bg-green-700 text-white border-green-800"
                    : "bg-slate-100 dark:bg-zinc-700 text-slate-800 dark:text-slate-100 border-slate-300 dark:border-zinc-600 hover:bg-slate-200"
                }`}
                aria-label={`Mudar tamanho da letra para ${size}`}
              >
                {size.toUpperCase()}
              </button>
            ))}
          </div>

          <button
            onClick={toggleDyslexia}
            id="btn-dyslexia"
            className={`w-full py-2.5 px-4 rounded-lg font-bold transition-all text-sm flex items-center justify-between border-2 ${
              settings.disabledDyslexiaFont === false || settings.dyslexicFont
                ? "bg-green-600 text-white border-green-700"
                : "bg-slate-200 dark:bg-zinc-700 text-slate-800 dark:text-white border-transparent hover:bg-slate-300 dark:hover:bg-zinc-600"
            }`}
            aria-pressed={settings.dyslexicFont}
          >
            <span>{langKeys["a11y.dyslexia"]}</span>
            <span className="text-xs font-mono uppercase bg-slate-400/20 px-2 py-0.5 rounded">
              {settings.dyslexicFont ? "Ativo" : "Inativo"}
            </span>
          </button>
        </div>

        {/* Guias de Leitura e Voz */}
        <div className="p-4 bg-white dark:bg-zinc-800 rounded-xl border border-slate-300 dark:border-zinc-700">
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-green-700 dark:text-green-400">
            <BookOpen className="w-5 h-5" /> Linhas e Leitura
          </h3>
          <div className="space-y-3">
            <button
              onClick={toggleReadingLine}
              id="btn-reading-guide"
              className={`w-full py-2.5 px-4 rounded-lg font-bold transition-all text-sm flex items-center justify-between border-2 ${
                settings.readingLine
                  ? "bg-teal-600 text-white border-teal-700 hover:bg-teal-500"
                  : "bg-slate-200 dark:bg-zinc-700 text-slate-800 dark:text-white border-transparent hover:bg-slate-300 dark:hover:bg-zinc-600"
              }`}
              aria-pressed={settings.readingLine}
            >
              <span>{langKeys["a11y.readingline"]}</span>
              <span className="text-xs font-mono uppercase bg-slate-400/20 px-2 py-0.5 rounded">
                {settings.readingLine ? "Ativo" : "Inativo"}
              </span>
            </button>

            <div className="text-xs text-slate-500 dark:text-zinc-400">
              <span className="font-semibold">{langKeys["a11y.shortcuts"]}:</span>
              <p className="mt-1">{langKeys["a11y.shortcuts.desc"]}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
