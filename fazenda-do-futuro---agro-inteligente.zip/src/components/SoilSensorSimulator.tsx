import React, { useState, useEffect } from "react";
import { SoilSensorReadings, SoilDiagnostic } from "../types";
import { Sliders, Droplet, Thermometer, Wind, AlertTriangle, CheckCircle2, FlaskConical } from "lucide-react";

interface SoilSensorSimulatorProps {
  onDiagnosticUpdate: (readings: SoilSensorReadings, diagnostic: SoilDiagnostic) => void;
  langKeys: Record<string, string>;
}

export const SoilSensorSimulator: React.FC<SoilSensorSimulatorProps> = ({
  onDiagnosticUpdate,
  langKeys,
}) => {
  const [readings, setReadings] = useState<SoilSensorReadings>({
    moisture: 38,
    ph: 6.2,
    nitrogen: 45,
    phosphorus: 28,
    potassium: 35,
    temperature: 22.4,
  });

  const [diagnostic, setDiagnostic] = useState<SoilDiagnostic>({
    status: "ideal",
    recommendations: [],
    suggestedCrops: [],
  });

  // Calculate recommendation engine locally based on Iretama standards
  useEffect(() => {
    const recs: string[] = [];
    const crops: string[] = [];
    let status: SoilDiagnostic["status"] = "ideal";

    // moisture checks
    if (readings.moisture < 30) {
      status = "warning";
      recs.push("Solo muito seco para plantio convencional de sequeiro. Recomenda-se acionamento do gotejamento solar inteligente ou irrigação localizada por aspersão.");
    } else if (readings.moisture > 65) {
      status = "warning";
      recs.push("Excesso de umidade detectado em solo argiloso de Iretama. Risco de apodrecimento radicular e proliferação de fungos. Suspenda a irrigação imediata.");
    } else {
      recs.push("Nível de umidade ideal (30% a 60%). Mantém boa aeração microbiológica e retenção de água.");
    }

    // pH checks
    if (readings.ph < 5.5) {
      status = "critical";
      recs.push("Solo excessivamente ácido (pH abaixo de 5.5). Risco de indisponibilidade de fósforo e intoxicação por alumínio. Faça aplicação de calcário agrícola (calagem) de forma superficial.");
    } else if (readings.ph > 7.2) {
      status = "warning";
      recs.push("Solo ligeiramente alcalino. Pode limitar a absorção de micronutrientes (ferro, manganês). Considere adubação foliar.");
    } else {
      recs.push("pH na faixa perfeita de neutralidade (5.5 a 7.0), ideal para absorção máxima de nutrientes em cultivos de soja e café de montanha.");
    }

    // Nitrogen check
    if (readings.nitrogen < 35) {
      if (status !== "critical") status = "warning";
      recs.push("Nitrogênio (N) está baixo. Adicione adubo verde (Crotalária ou Feijão de Porco) na rotação de cultura para fixar nitrogênio biológico no solo de forma sustentável, evitando adubos minerais nitrogenados sintéticos.");
    } else {
      recs.push("Disponibilidade de nitrogênio adequada para a fase vegetativa.");
    }

    // Phosphorus & Potassium
    if (readings.phosphorus < 20 || readings.potassium < 25) {
      recs.push("Nutrientes P ou K em nível baixo. Adicione fosfatos naturais reativos ou cinzas de biomassa vegetal para correção ecológica.");
    }

    // Crop Suggestions based on sensor values and Iretama PR conditions
    if (readings.ph >= 5.8 && readings.ph <= 6.8 && readings.moisture >= 35 && readings.moisture <= 55) {
      crops.push("Soja Sustentável (Variedades adaptadas a Campo Mourão)");
      crops.push("Café Especial de Montanha Iretama");
    }
    if (readings.moisture >= 30 && readings.moisture <= 50) {
      crops.push("Milho Safrinha Consorciado com Braquiária");
    }
    if (readings.ph >= 5.5 && readings.ph <= 6.5) {
      crops.push("Trigo de Inverno (Zoneamento Paraná)");
    }
    if (crops.length === 0) {
      crops.push("Coberturas verdes para recuperação do solo (Aveia Preta, Nabo Forrageiro)");
    }

    const nextDiagnostic: SoilDiagnostic = { status, recommendations: recs, suggestedCrops: crops };
    setDiagnostic(nextDiagnostic);
    onDiagnosticUpdate(readings, nextDiagnostic);
  }, [readings]);

  const updateReading = (key: keyof SoilSensorReadings, val: number) => {
    setReadings((prev) => ({ ...prev, [key]: val }));
  };

  return (
    <section
      id="sensores"
      className="p-6 bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl shadow-lg transition-all"
      aria-labelledby="sensors-title-id"
    >
      <div className="flex items-center gap-3 mb-2">
        <Sliders className="w-8 h-8 text-green-700 dark:text-green-500" />
        <h2 id="sensors-title-id" className="text-2xl font-bold text-slate-800 dark:text-white">
          {langKeys["sensors.title"]}
        </h2>
      </div>
      <p className="text-sm text-slate-500 dark:text-zinc-400 mb-6">
        {langKeys["sensors.subtitle"]}
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Controles de Simulação */}
        <div className="space-y-6">
          {/* Umidade */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-700 dark:text-slate-200">
              <label htmlFor="input-moisture" className="font-semibold flex items-center gap-2">
                <Droplet className="w-5 h-5 text-teal-600" /> {langKeys["sensors.moisture"]}
              </label>
              <span className="font-mono text-sm bg-teal-100 dark:bg-teal-900/30 text-teal-800 dark:text-teal-300 px-2 py-0.5 rounded">
                {readings.moisture}%
              </span>
            </div>
            <input
              id="input-moisture"
              type="range"
              min="10"
              max="90"
              value={readings.moisture}
              onChange={(e) => updateReading("moisture", parseInt(e.target.value))}
              className="w-full accent-teal-600 cursor-pointer h-2 bg-slate-200 dark:bg-zinc-700 rounded-lg"
            />
          </div>

          {/* pH */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-700 dark:text-slate-200">
              <label htmlFor="input-ph" className="font-semibold flex items-center gap-2">
                <FlaskConical className="w-5 h-5 text-amber-600" /> {langKeys["sensors.ph"]}
              </label>
              <span className="font-mono text-sm bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 px-2 py-0.5 rounded">
                {readings.ph.toFixed(1)}
              </span>
            </div>
            <input
              id="input-ph"
              type="range"
              min="4"
              max="9"
              step="0.1"
              value={readings.ph}
              onChange={(e) => updateReading("ph", parseFloat(e.target.value))}
              className="w-full accent-amber-600 cursor-pointer h-2 bg-slate-200 dark:bg-zinc-700 rounded-lg"
            />
          </div>

          {/* Nitrogen (N) */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-700 dark:text-slate-200">
              <label htmlFor="input-nitrogen" className="font-semibold flex items-center gap-1.5">
                <span className="text-red-600 font-bold font-mono">N</span> {langKeys["sensors.nitrogen"]}
              </label>
              <span className="font-mono text-sm bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 px-2 py-0.5 rounded">
                {readings.nitrogen} mg/kg
              </span>
            </div>
            <input
              id="input-nitrogen"
              type="range"
              min="10"
              max="100"
              value={readings.nitrogen}
              onChange={(e) => updateReading("nitrogen", parseInt(e.target.value))}
              className="w-full accent-red-600 cursor-pointer h-2 bg-slate-200 dark:bg-zinc-700 rounded-lg"
            />
          </div>

          {/* Phosphorus (P) */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-700 dark:text-slate-200">
              <label htmlFor="input-phosphorus" className="font-semibold flex items-center gap-1.5">
                <span className="text-purple-600 font-bold font-mono">P</span> {langKeys["sensors.phosphorus"]}
              </label>
              <span className="font-mono text-sm bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300 px-2 py-0.5 rounded">
                {readings.phosphorus} mg/kg
              </span>
            </div>
            <input
              id="input-phosphorus"
              type="range"
              min="5"
              max="60"
              value={readings.phosphorus}
              onChange={(e) => updateReading("phosphorus", parseInt(e.target.value))}
              className="w-full accent-purple-600 cursor-pointer h-2 bg-slate-200 dark:bg-zinc-700 rounded-lg"
            />
          </div>

          {/* Potassium (K) */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-700 dark:text-slate-200">
              <label htmlFor="input-potassium" className="font-semibold flex items-center gap-1.5">
                <span className="text-blue-600 font-bold font-mono">K</span> {langKeys["sensors.potassium"]}
              </label>
              <span className="font-mono text-sm bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded">
                {readings.potassium} mg/kg
              </span>
            </div>
            <input
              id="input-potassium"
              type="range"
              min="10"
              max="80"
              value={readings.potassium}
              onChange={(e) => updateReading("potassium", parseInt(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer h-2 bg-slate-200 dark:bg-zinc-700 rounded-lg"
            />
          </div>

          {/* Temperature */}
          <div>
            <div className="flex justify-between items-center mb-1 text-slate-700 dark:text-slate-200">
              <label htmlFor="input-temperature" className="font-semibold flex items-center gap-2">
                <Thermometer className="w-5 h-5 text-orange-600" /> {langKeys["sensors.temp"]}
              </label>
              <span className="font-mono text-sm bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300 px-2 py-0.5 rounded">
                {readings.temperature}°C
              </span>
            </div>
            <input
              id="input-temperature"
              type="range"
              min="5"
              max="45"
              step="0.5"
              value={readings.temperature}
              onChange={(e) => updateReading("temperature", parseFloat(e.target.value))}
              className="w-full accent-orange-600 cursor-pointer h-2 bg-slate-200 dark:bg-zinc-700 rounded-lg"
            />
          </div>
        </div>

        {/* Diagnóstico & Recomendações */}
        <div className="p-5 bg-slate-50 dark:bg-zinc-900/50 border-2 border-slate-300 dark:border-zinc-700 rounded-xl flex flex-col justify-between">
          <div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-3">
              {langKeys["sensors.diagnostic"]}
            </h3>

            {/* Status Badge */}
            <div className="mb-4 flex items-center gap-3">
              <span className="text-sm font-semibold text-slate-600 dark:text-zinc-300">
                {langKeys["sensors.status"]}
              </span>
              {diagnostic.status === "ideal" && (
                <span className="px-3 py-1 bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300 text-xs font-bold rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" /> {langKeys["sensors.ideal"]}
                </span>
              )}
              {diagnostic.status === "warning" && (
                <span className="px-3 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-950/40 dark:text-yellow-300 text-xs font-bold rounded-full flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4" /> {langKeys["sensors.warning"]}
                </span>
              )}
              {diagnostic.status === "critical" && (
                <span className="px-3 py-1 bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300 text-xs font-bold rounded-full flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4" /> {langKeys["sensors.critical"]}
                </span>
              )}
            </div>

            {/* Recomendações */}
            <h4 className="font-bold text-sm text-green-700 dark:text-green-400 mb-2">
              {langKeys["sensors.rec.title"]}
            </h4>
            <ul className="space-y-2 mb-4 text-sm text-slate-700 dark:text-zinc-300 list-disc pl-5">
              {diagnostic.recommendations.map((rec, i) => (
                <li key={i}>{rec}</li>
              ))}
            </ul>
          </div>

          {/* Cultivos Recomendados */}
          <div className="pt-4 border-t border-slate-200 dark:border-zinc-700">
            <h4 className="font-bold text-sm text-green-700 dark:text-green-400 mb-2">
              {langKeys["sensors.crops.title"]}
            </h4>
            <div className="flex flex-wrap gap-2">
              {diagnostic.suggestedCrops.map((crop, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 bg-green-50 dark:bg-zinc-800 text-green-800 dark:text-green-300 text-xs font-semibold rounded-md border border-green-200 dark:border-zinc-700 shadow-sm"
                >
                  {crop}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
