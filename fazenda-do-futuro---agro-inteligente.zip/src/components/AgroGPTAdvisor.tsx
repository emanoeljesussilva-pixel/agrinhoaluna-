import React, { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Volume2, VolumeX, Sparkles, RefreshCw } from "lucide-react";

interface AgroGPTAdvisorProps {
  langKeys: Record<string, string>;
  soilContext: any;
}

export const AgroGPTAdvisor: React.FC<AgroGPTAdvisorProps> = ({
  langKeys,
  soilContext,
}) => {
  const [messages, setMessages] = useState<Array<{ sender: "ai" | "user"; text: string }>>([
    {
      sender: "ai",
      text: "Olá! Sou o AgroIretamaGPT, seu especialista digital em sustentabilidade agrícola e precisão no Paraná. Como posso ajudar com sua plantação, sensores ou rastreabilidade blockchain hoje?",
    },
  ]);
  const [inputValue, setInputValue] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [synth, setSynth] = useState<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      setSynth(window.speechSynthesis);
    }
  }, []);

  const handleSpeak = (text: string) => {
    if (!synth) return;
    if (isSpeaking) {
      synth.cancel();
      setIsSpeaking(false);
      return;
    }

    const cleanText = text.replace(/[#*`_]/g, ""); // strip markdown formatting for clean TTS
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = "pt-BR";
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    synth.speak(utterance);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || loading) return;

    const userText = inputValue;
    setMessages((prev) => [...prev, { sender: "user", text: userText }]);
    setInputValue("");
    setLoading(true);

    // Timeout simulado para a digitação da IA parecer natural
    const simulateLocalResponse = () => {
      const textLower = userText.toLowerCase();
      const readings = soilContext.readings || { moisture: 38, ph: 6.2, nitrogen: 45, phosphorus: 28, potassium: 35, temperature: 22.4 };
      const diagnostic = soilContext.diagnostic || { status: "ideal", recommendations: [] };
      
      let reply = "";

      if (textLower.includes("soja")) {
        reply = `O cultivo de Soja Sustentável em Iretama/PR está com ótimas perspectivas técnicas! \n\nConsiderando os sensores atuais (pH de ${readings.ph.toFixed(1)} e Umidade de ${readings.moisture}%), o ambiente está ${readings.ph >= 5.8 && readings.ph <= 6.8 ? "ideal" : "fora do intervalo padrão de 5.8 a 6.8"}. Recomenda-se sementes adaptadas para o norte/centro do Paraná e rotação de culturas com braquiária para melhorar a física do solo argiloso.`;
      } else if (textLower.includes("café") || textLower.includes("cafe")) {
        reply = `O Café Especial de Montanha é uma joia de Iretama, beneficiado pela altitude local (acima de 750m). \n\nCom seus sensores em pH ${readings.ph.toFixed(1)} e Nitrogênio em ${readings.nitrogen} mg/kg, o cafeeiro absorve melhor os microelementos. Evite excesso de umidade (atualmente em ${readings.moisture}%) nas raízes para prevenir fungos como a ferrugem do cafeeiro.`;
      } else if (textLower.includes("ph") || textLower.includes("calc") || textLower.includes("acidez") || textLower.includes("calagem")) {
        if (readings.ph < 5.5) {
          reply = `Alerta de Acidez! O pH atual está crítico em ${readings.ph.toFixed(1)}. \n\nPara o solo típico argiloso de Iretama, indica-se calagem com calcário dolomítico (rico em Magnésio) para elevar o pH para a faixa ideal (5.8 a 6.5) e neutralizar o alumínio tóxico. Faça a aplicação com antecedência mínima de 60 a 90 dias antes do plantio.`;
        } else {
          reply = `O pH atual está em ${readings.ph.toFixed(1)}, o que é considerado adequado para a maioria das culturas anuais (soja e milho). Mantenha o monitoramento constante por zona para evitar alcalinização desnecessária.`;
        }
      } else if (textLower.includes("umidade") || textLower.includes("água") || textLower.includes("agua") || textLower.includes("irrig")) {
        reply = `Monitoramento hídrico inteligente: O solo apresenta ${readings.moisture}% de umidade. \n\nPara solos argilosos de Iretama, a faixa recomendada de sequeiro sustentável é de 35% a 55%. ${readings.moisture < 30 ? "O solo está muito seco! Ative o gotejamento solar inteligente." : readings.moisture > 65 ? "Atenção: Solo saturado! Risco de lixiviação de nutrientes." : "Umidade excelente para brotação e desenvolvimento de raízes."}`;
      } else if (textLower.includes("blockchain") || textLower.includes("rastre") || textLower.includes("lote") || textLower.includes("contrato")) {
        reply = `A arquitetura AgroChain integrada ao nó #PR-Iretama-01 registra os metadados de plantio em IPFS de forma imutável. \n\nIsso permite que compradores na União Europeia e em mercados de prêmio rastreiem que seu lote atual de cultivo foi produzido com redução de defensivos sintéticos e com zero desmatamento, validado pelo CAR (Cadastro Ambiental Rural) do Paraná.`;
      } else if (textLower.includes("ajuda") || textLower.includes("como funciona") || textLower.includes("sensores")) {
        reply = `Posso ajudar você a analisar as leituras do solo! \n\nSeus sensores atuais marcam:\n- Umidade: ${readings.moisture}%\n- pH: ${readings.ph.toFixed(1)}\n- Nitrogênio (N): ${readings.nitrogen} mg/kg\n- Fósforo (P): ${readings.phosphorus} mg/kg\n- Potássio (K): ${readings.potassium} mg/kg\n\nQual destas métricas você deseja que eu avalie detalhadamente com foco em sustentabilidade?`;
      } else {
        reply = `Entendido! Sua pergunta sobre "${userText}" é de extrema importância para o manejo sustentável em Iretama/PR. \n\nAnalisando o contexto atual de sua fazenda digital:\n- O pH do solo está em ${readings.ph.toFixed(1)} (${readings.ph < 5.5 ? "Necessita calagem urgente" : "Faixa estável"}).\n- A umidade está em ${readings.moisture}%\n- N-P-K disponível: ${readings.nitrogen}-${readings.phosphorus}-${readings.potassium} mg/kg.\n\nSugerimos manter as práticas de rotação de cobertura verde com aveia-preta e nabo forrageiro para reter água e micronutrientes de forma sustentável. Qual outra dúvida técnica você tem?`;
      }

      setMessages((prev) => [...prev, { sender: "ai", text: reply }]);
      setLoading(false);
    };

    try {
      const response = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userText,
          contextData: soilContext,
        }),
      });

      if (!response.ok) throw new Error("API Offline");
      const data = await response.json();
      setMessages((prev) => [...prev, { sender: "ai", text: data.text || "Desculpe, não consegui obter resposta." }]);
      setLoading(false);
    } catch (err) {
      console.warn("AgroTech: Utilizando NLP de resposta local para ambiente client-side (vscode.dev/offline):", err);
      // Aguarda 1 segundo para simular pensamento realista da IA
      setTimeout(simulateLocalResponse, 1000);
    }
  };

  return (
    <section
      id="advisor"
      className="p-6 bg-slate-100 dark:bg-zinc-900 border-2 border-green-600 rounded-2xl shadow-xl transition-all"
      aria-labelledby="advisor-title"
    >
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <Bot className="w-8 h-8 text-green-700 dark:text-green-500" />
          <h2 id="advisor-title" className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            AgroIretamaGPT <span className="text-xs bg-green-200 dark:bg-green-950 text-green-800 dark:text-green-300 px-2 py-0.5 rounded-full flex items-center gap-1 font-mono"><Sparkles className="w-3 h-3 text-green-600" /> AI Ativa</span>
          </h2>
        </div>
        
        {synth && (
          <button
            onClick={() => synth.cancel()}
            className="text-xs py-1 px-3 bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 rounded-lg text-slate-600 dark:text-zinc-300 hover:bg-slate-100"
            aria-label="Silenciar leitor de voz do assistente"
          >
            Mudar Voz
          </button>
        )}
      </div>

      <div className="flex flex-col h-[400px] bg-white dark:bg-zinc-950 border border-slate-300 dark:border-zinc-800 rounded-xl overflow-hidden shadow-inner">
        {/* Histórico de Mensagens */}
        <div 
          className="flex-1 overflow-y-auto p-4 space-y-4"
          role="log"
          aria-label="Histórico de mensagens do chat"
          aria-live="polite"
        >
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex items-start gap-2.5 max-w-[85%] ${
                m.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
              }`}
            >
              <div className={`p-2 rounded-full ${m.sender === "user" ? "bg-green-700 text-white" : "bg-slate-200 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300"}`}>
                {m.sender === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>
              
              <div className="relative group">
                <div
                  className={`p-3 rounded-2xl text-sm ${
                    m.sender === "user"
                      ? "bg-green-700 text-white rounded-tr-none"
                      : "bg-slate-100 dark:bg-zinc-900 text-slate-800 dark:text-zinc-200 border border-slate-200 dark:border-zinc-800 rounded-tl-none whitespace-pre-line"
                  }`}
                >
                  {m.text}
                </div>
                
                {/* Audio Reader Trigger for Blind/Visually Impaired */}
                {m.sender === "ai" && synth && (
                  <button
                    onClick={() => handleSpeak(m.text)}
                    className="absolute -bottom-6 left-0 text-[10px] text-green-700 dark:text-green-400 font-bold flex items-center gap-1 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity bg-white dark:bg-zinc-900 py-0.5 px-2 rounded-full border border-slate-200 shadow-sm"
                    aria-label="Ouvir resposta em áudio"
                  >
                    {isSpeaking ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                    <span>{isSpeaking ? "Parar Leitura" : "Ouvir Mensagem"}</span>
                  </button>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex items-center gap-2 text-slate-500 font-semibold text-xs ml-10 p-2 bg-slate-50 dark:bg-zinc-900/50 border border-slate-200 dark:border-zinc-800 rounded-xl max-w-max">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>AgroIretamaGPT está formulando resposta técnica...</span>
            </div>
          )}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSend} className="p-3 border-t border-slate-300 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Pergunte sobre soja em Iretama, calagem, blockchain..."
            aria-label="Escreva sua pergunta agrícola para o assistente virtual"
            className="flex-1 bg-white dark:bg-zinc-950 border border-slate-300 dark:border-zinc-800 rounded-lg px-4 py-2.5 text-sm text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-green-600 focus:border-transparent transition-all"
          />
          <button
            type="submit"
            disabled={loading}
            className="bg-green-700 hover:bg-green-600 disabled:bg-slate-400 text-white p-2.5 rounded-lg flex items-center justify-center shadow transition-all cursor-pointer"
            aria-label="Enviar mensagem"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </section>
  );
};
