import React, { useState, useEffect } from "react";
import { translations } from "./translations";
import { librasAgroGlossary } from "./librasData";
import { AccessibilitySettings, AppLanguage, SoilSensorReadings, SoilDiagnostic } from "./types";
import { AccessibilityPanel } from "./components/AccessibilityPanel";
import { SoilSensorSimulator } from "./components/SoilSensorSimulator";
import { SustainabilityDashboard } from "./components/SustainabilityDashboard";
import { BlockchainLedger } from "./components/BlockchainLedger";
import { ParanaGovernmentData } from "./components/ParanaGovernmentData";
import { AgroGPTAdvisor } from "./components/AgroGPTAdvisor";
import {
  HelpCircle,
  Eye,
  Type,
  Globe,
  Compass,
  FileText,
  ShieldAlert,
  Menu,
  X,
  Languages,
  BookOpen,
  Volume2,
  ChevronRight,
  Sparkles,
  ArrowUp
} from "lucide-react";
import { motion } from "motion/react";

export default function App() {
  // 1. Accessibility & Theme states
  const [settings, setSettings] = useState<AccessibilitySettings>({
    fontSize: "base",
    highContrast: false,
    dyslexicFont: false,
    readingLine: false,
    readingLineY: 250,
    screenReaderActive: true,
    monochrome: false,
  });

  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [lang, setLang] = useState<AppLanguage>("pt-BR");
  const [announcement, setAnnouncement] = useState<string>("");
  const [showA11yMenu, setShowA11yMenu] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Soil Context state shared to give smart diagnostics in the AI Chat
  const [soilContext, setSoilContext] = useState<{ readings: SoilSensorReadings | null; diagnostic: SoilDiagnostic | null }>({
    readings: null,
    diagnostic: null,
  });

  // Active LIBRAS Word
  const [selectedLibrasWord, setSelectedLibrasWord] = useState<string>("Sustentabilidade");

  // Voice Speech Synthesis State for whole-page reading assistant
  const [isSpeakingPage, setIsSpeakingPage] = useState<boolean>(false);

  // Dynamic Typewriter Effect for the Hero title
  const [typewriterText, setTypewriterText] = useState<string>("Futuro Sustentável");
  const phrases = [
    "Futuro Sustentável",
    "Agro Inteligente",
    "Tecnologia Verde",
    "Biomas Protegidos",
    "Iretama de Precisão"
  ];
  
  useEffect(() => {
    let currentIdx = 0;
    const interval = setInterval(() => {
      currentIdx = (currentIdx + 1) % phrases.length;
      setTypewriterText(phrases[currentIdx]);
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  // 2. Load automatic OS theme preference and register listeners
  useEffect(() => {
    const systemPrefersDark = window.matchMedia("(prefers-color-scheme: dark)");
    const applySystemTheme = (e: MediaQueryListEvent | MediaQueryList) => {
      setTheme(e.matches ? "dark" : "light");
    };
    applySystemTheme(systemPrefersDark);
    systemPrefersDark.addEventListener("change", applySystemTheme);
    return () => systemPrefersDark.removeEventListener("change", applySystemTheme);
  }, []);

  // Handle keyboard shortcuts (Alt + keys for main blocks jumping)
  useEffect(() => {
    const handleShortcuts = (e: KeyboardEvent) => {
      if (e.altKey) {
        const key = e.key.toLowerCase();
        let targetId = "";
        
        if (key === "h") targetId = "hero";
        if (key === "t") targetId = "tecnologias";
        if (key === "s") targetId = "sensores";
        if (key === "d") targetId = "dashboard";
        if (key === "b") targetId = "blockchain";
        if (key === "g") targetId = "governo";
        if (key === "l") targetId = "libras";
        if (key === "a") targetId = "acessibilidade";

        if (targetId) {
          e.preventDefault();
          const elem = document.getElementById(targetId);
          if (elem) {
            elem.scrollIntoView({ behavior: "smooth" });
            elem.focus();
            announceAction(`Focado na seção ${targetId}`);
          }
        }
      }
    };
    window.addEventListener("keydown", handleShortcuts);
    return () => window.removeEventListener("keydown", handleShortcuts);
  }, []);

  // Aria Live announcer utility
  const announceAction = (msg: string) => {
    setAnnouncement(msg);
    // Clear after a few seconds so it can be announced again if repeated
    setTimeout(() => setAnnouncement(""), 3000);
  };

  // Track cursor for reading guide lines
  const handleMouseMove = (e: React.MouseEvent) => {
    if (settings.readingLine) {
      setSettings((prev) => ({ ...prev, readingLineY: e.clientY }));
    }
  };

  const currentLanguageKeys = translations[lang];

  // Manual theme switcher
  const toggleTheme = () => {
    setTheme((prev) => {
      const nextTheme = prev === "dark" ? "light" : "dark";
      announceAction(`Tema alterado para ${nextTheme === "dark" ? "Escuro" : "Claro"}`);
      return nextTheme;
    });
  };

  // Text-To-Speech for reading entire section summary
  const readPageBriefing = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const synth = window.speechSynthesis;

    if (isSpeakingPage) {
      synth.cancel();
      setIsSpeakingPage(false);
      announceAction("Leitura em voz alta interrompida.");
      return;
    }

    const text = `Bem-vindo à Fazenda do Futuro Agro Inteligente em Iretama, Paraná. 
    Esta plataforma foi construída seguindo as diretrizes WCAG 2.1 de acessibilidade completa. 
    Atualmente você está visualizando no modo de idioma ${lang}. 
    As principais seções são: Tecnologias de Precisão, Simulador de Sensores de Solo, Indicadores de Impacto Ambiental, Trazabilidade Blockchain e consultas oficiais ao IDR-Paraná e IBGE.`;
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "pt-BR";
    utterance.onend = () => setIsSpeakingPage(false);
    utterance.onerror = () => setIsSpeakingPage(false);
    
    setIsSpeakingPage(true);
    synth.speak(utterance);
    announceAction("Iniciando áudio-descrição geral da plataforma.");
  };

  return (
    <div
      onMouseMove={handleMouseMove}
      className={`min-h-screen relative transition-colors duration-300 font-sans ${
        theme === "dark" ? "bg-zinc-950 text-slate-100 dark" : "bg-slate-50 text-slate-900"
      } ${settings.highContrast ? "high-contrast" : ""} ${
        settings.dyslexicFont ? "font-dyslexic" : ""
      } ${settings.monochrome ? "filter grayscale" : ""}`}
    >
      {/* 1. Skip To Main Content Shortcut (WCAG Guideline 2.4.1) */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[9999] bg-yellow-400 text-black py-2 px-4 rounded font-extrabold border-2 border-black shadow"
      >
        Pular para o Conteúdo Principal (Teclado)
      </a>

      {/* 2. Aria Live Announcement Container (Visually Hidden) */}
      <div className="sr-only" aria-live="assertive" aria-atomic="true">
        {announcement}
      </div>

      {/* 3. Reading Ruler Guide */}
      {settings.readingLine && (
        <div
          className="fixed left-0 w-full h-1 bg-yellow-400 z-[9999] pointer-events-none shadow"
          style={{ top: `${settings.readingLineY}px` }}
          aria-hidden="true"
        />
      )}

      {/* 4. Accessibility Float Buttons */}
      <div className="fixed bottom-6 right-6 z-[999] flex flex-col gap-3">
        <button
          onClick={() => {
            setShowA11yMenu(!showA11yMenu);
            announceAction(showA11yMenu ? "Painel de acessibilidade fechado" : "Painel de acessibilidade aberto");
          }}
          className="bg-green-700 hover:bg-green-600 text-white p-3.5 rounded-full shadow-2xl flex items-center justify-center border-2 border-white hover:scale-105 transition-all cursor-pointer"
          aria-label="Abrir opções de acessibilidade de alto contraste e fontes"
          aria-expanded={showA11yMenu}
        >
          <Eye className="w-6 h-6" />
        </button>

        <button
          onClick={() => {
            window.scrollTo({ top: 0, behavior: "smooth" });
            announceAction("Voltando ao topo da página");
          }}
          className="bg-slate-800 hover:bg-slate-700 text-white p-3 rounded-full shadow-xl flex items-center justify-center hover:scale-105 transition-all cursor-pointer"
          aria-label="Voltar para o topo"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      </div>

      {/* 5. Floating A11y Panel Drawer */}
      {showA11yMenu && (
        <div className="fixed inset-0 bg-black/60 z-[9999] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-zinc-900 border-2 border-green-600 rounded-2xl max-w-2xl w-full p-6 relative shadow-2xl">
            <button
              onClick={() => setShowA11yMenu(false)}
              className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-white p-2"
              aria-label="Fechar painel de acessibilidade"
            >
              <X className="w-6 h-6" />
            </button>
            <AccessibilityPanel
              settings={settings}
              setSettings={setSettings}
              onAnnounce={announceAction}
              langKeys={currentLanguageKeys}
            />
          </div>
        </div>
      )}

      {/* 6. Navigation Bar */}
      <nav className="sticky top-0 z-[100] w-full border-b bg-white/90 dark:bg-zinc-950/90 backdrop-blur border-slate-200 dark:border-zinc-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-20">
          <div className="flex items-center gap-2">
            <span className="text-xl font-black tracking-tight text-slate-900 dark:text-white">
              Agro<span className="text-green-600">Tech</span>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 bg-green-100 dark:bg-green-950 text-green-700 dark:text-green-300 rounded font-mono uppercase">
              Iretama PR
            </span>
          </div>

          {/* Desktop Links */}
          <ul className="hidden xl:flex items-center gap-6 text-sm font-bold">
            <li><a href="#hero" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.home"]}</a></li>
            <li><a href="#sobre" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.about"]}</a></li>
            <li><a href="#tecnologias" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.tech"]}</a></li>
            <li><a href="#sensores" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.sensors"]}</a></li>
            <li><a href="#dashboard" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.dashboard"]}</a></li>
            <li><a href="#blockchain" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.trace"]}</a></li>
            <li><a href="#governo" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.governo"]}</a></li>
            <li><a href="#libras" className="hover:text-green-600 dark:hover:text-green-400">{currentLanguageKeys["nav.libras"]}</a></li>
          </ul>

          {/* Right Controls Bar */}
          <div className="flex items-center gap-3">
            {/* Audio describer general button */}
            <button
              onClick={readPageBriefing}
              className={`p-2 rounded-lg border flex items-center gap-1 text-xs font-bold transition-all cursor-pointer ${
                isSpeakingPage
                  ? "bg-red-100 text-red-800 border-red-300 animate-pulse"
                  : "bg-slate-100 dark:bg-zinc-900 border-slate-200 dark:border-zinc-800 text-slate-700 dark:text-zinc-300 hover:bg-slate-200"
              }`}
              aria-label="Ouvir áudio-descrição resumida da página"
            >
              <Volume2 className="w-4 h-4" />
              <span className="hidden sm:inline">{isSpeakingPage ? "Silenciar" : "Áudio Guia"}</span>
            </button>

            {/* Language Switcher Dropdown */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 p-1 rounded-lg">
              <Languages className="w-4 h-4 text-slate-500 ml-1" />
              <select
                value={lang}
                onChange={(e) => {
                  const targetLang = e.target.value as AppLanguage;
                  setLang(targetLang);
                  announceAction(`Idioma alterado para ${targetLang}`);
                }}
                className="text-xs font-bold bg-transparent text-slate-700 dark:text-zinc-300 outline-none pr-1 cursor-pointer"
                aria-label="Selecione o idioma da página"
              >
                <option value="pt-BR">Português</option>
                <option value="pt-Simple">Acessível (Simples)</option>
                <option value="en-US">English</option>
                <option value="es-ES">Español</option>
              </select>
            </div>

            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              className="p-2 bg-slate-100 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-lg text-slate-600 dark:text-zinc-300 hover:bg-slate-200 cursor-pointer"
              aria-label={theme === "dark" ? "Mudar para Tema Claro" : "Mudar para Tema Escuro"}
            >
              {theme === "dark" ? "☀️" : "🌙"}
            </button>

            {/* Mobile Nav Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 text-slate-600 dark:text-zinc-300"
              aria-label="Menu móvel"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav Drawer */}
        {mobileMenuOpen && (
          <div className="xl:hidden bg-white dark:bg-zinc-950 border-t border-slate-200 dark:border-zinc-800 p-4 space-y-3 font-bold text-sm">
            <a href="#hero" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.home"]}</a>
            <a href="#sobre" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.about"]}</a>
            <a href="#tecnologias" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.tech"]}</a>
            <a href="#sensores" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.sensors"]}</a>
            <a href="#dashboard" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.dashboard"]}</a>
            <a href="#blockchain" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.trace"]}</a>
            <a href="#governo" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.governo"]}</a>
            <a href="#libras" onClick={() => setMobileMenuOpen(false)} className="block py-2 hover:text-green-600">{currentLanguageKeys["nav.libras"]}</a>
          </div>
        )}
      </nav>

      {/* 7. Main Body Layout */}
      <main id="main-content" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* 1. HERO SECTION */}
        <header
          id="hero"
          className="relative rounded-3xl overflow-hidden min-h-[500px] flex items-center justify-center text-center p-8 bg-cover bg-center shadow-2xl transition-all"
          style={{
            backgroundImage: `linear-gradient(180deg, rgba(0,0,0,0.6) 0%, rgba(26,26,26,0.95) 100%), url('https://images.unsplash.com/photo-1625246333195-78d9c38ad449?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80')`,
          }}
          aria-label="Destaque da Plataforma"
        >
          <div className="relative z-10 max-w-4xl space-y-6">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-600/30 text-green-300 text-xs font-bold rounded-full border border-green-500/50 uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" /> {currentLanguageKeys["hero.badge"]}
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-tight">
              {currentLanguageKeys["hero.title"]} <br />
              <span className="text-green-400 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                {typewriterText}
              </span>
            </h1>
            <p className="text-base sm:text-lg lg:text-xl text-slate-300 font-medium max-w-2xl mx-auto leading-relaxed">
              {currentLanguageKeys["hero.subtitle"]}
            </p>
            <div className="pt-4 flex flex-wrap justify-center gap-4">
              <a
                href="#sensores"
                className="bg-green-700 hover:bg-green-600 text-white font-extrabold py-3.5 px-8 rounded-full shadow-lg hover:shadow-green-900/40 border-2 border-transparent hover:-translate-y-0.5 transition-all cursor-pointer"
              >
                {currentLanguageKeys["hero.cta"]}
              </a>
              <a
                href="#sobre"
                className="bg-white/10 hover:bg-white/15 text-white font-extrabold py-3.5 px-8 rounded-full backdrop-blur-md border-2 border-white/20 hover:-translate-y-0.5 transition-all cursor-pointer"
              >
                Sobre Iretama, PR
              </a>
            </div>
          </div>
        </header>

        {/* 2. ABOUT IRETAMA SECTION */}
        <section id="sobre" className="space-y-6" aria-labelledby="sobre-title">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <h2 id="sobre-title" className="text-3xl font-black text-slate-900 dark:text-white">
              {currentLanguageKeys["about.title"]}
            </h2>
            <p className="text-sm text-slate-500 dark:text-zinc-400">
              Urgência na conservação ambiental e inovação tecnológica na Bacia Hidrográfica regional.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-4 text-slate-700 dark:text-zinc-300 leading-relaxed text-sm">
              <p className="font-medium text-slate-800 dark:text-zinc-200">
                {currentLanguageKeys["about.desc1"]}
              </p>
              <p>
                {currentLanguageKeys["about.desc2"]}
              </p>
              <div className="p-4 bg-green-50 dark:bg-zinc-900/30 border-l-4 border-green-600 rounded-r-xl">
                <span className="font-bold text-green-800 dark:text-green-400 block mb-1">
                  Transição Agroecológica Protegida:
                </span>
                <p className="text-xs text-slate-600 dark:text-zinc-400">
                  A região de Iretama possui nascentes vulneráveis e matas ciliares ricas que demandam monitoramento preciso contra assoreamento e defensivos persistentes. Nossas inovações garantem preservação contínua.
                </p>
              </div>
            </div>

            {/* Grid de Destaques de Iretama */}
            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-1 gap-4">
              <div className="p-4 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl flex gap-3 items-start">
                <div className="p-2 bg-green-100 dark:bg-green-950 text-green-700 rounded-lg">🌲</div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    {currentLanguageKeys["about.card1.title"]}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                    {currentLanguageKeys["about.card1.desc"]}
                  </p>
                </div>
              </div>

              <div className="p-4 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl flex gap-3 items-start">
                <div className="p-2 bg-blue-100 dark:bg-blue-950 text-blue-700 rounded-lg">👨‍👩‍👦</div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    {currentLanguageKeys["about.card2.title"]}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                    {currentLanguageKeys["about.card2.desc"]}
                  </p>
                </div>
              </div>

              <div className="p-4 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl flex gap-3 items-start">
                <div className="p-2 bg-amber-100 dark:bg-amber-950 text-amber-700 rounded-lg">🐾</div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    {currentLanguageKeys["about.card3.title"]}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                    {currentLanguageKeys["about.card3.desc"]}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3. PRECISION TECH CARDS */}
        <section id="tecnologias" className="space-y-6" aria-labelledby="tech-title">
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <h2 id="tech-title" className="text-3xl font-black text-slate-900 dark:text-white">
              {currentLanguageKeys["tech.title"]}
            </h2>
            <p className="text-sm text-slate-500 dark:text-zinc-400">
              {currentLanguageKeys["tech.subtitle"]}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl shadow hover:shadow-xl hover:border-green-600 transition-all focus-within:ring-2 focus-within:ring-green-600">
              <span className="text-3xl mb-4 block">📡</span>
              <h3 className="text-lg font-bold text-slate-950 dark:text-white">
                {currentLanguageKeys["tech.card1.title"]}
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400 mt-2 mb-4 leading-relaxed">
                {currentLanguageKeys["tech.card1.desc"]}
              </p>
              <span className="inline-block px-3 py-1 bg-teal-100 dark:bg-teal-950/40 text-teal-800 dark:text-teal-300 text-xs font-bold rounded-full">
                {currentLanguageKeys["tech.card1.badge"]}
              </span>
            </div>

            <div className="p-6 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl shadow hover:shadow-xl hover:border-green-600 transition-all focus-within:ring-2 focus-within:ring-green-600">
              <span className="text-3xl mb-4 block">🚁</span>
              <h3 className="text-lg font-bold text-slate-950 dark:text-white">
                {currentLanguageKeys["tech.card2.title"]}
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400 mt-2 mb-4 leading-relaxed">
                {currentLanguageKeys["tech.card2.desc"]}
              </p>
              <span className="inline-block px-3 py-1 bg-green-100 dark:bg-green-950/40 text-green-800 dark:text-green-300 text-xs font-bold rounded-full">
                {currentLanguageKeys["tech.card2.badge"]}
              </span>
            </div>

            <div className="p-6 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl shadow hover:shadow-xl hover:border-green-600 transition-all focus-within:ring-2 focus-within:ring-green-600">
              <span className="text-3xl mb-4 block">🤖</span>
              <h3 className="text-lg font-bold text-slate-950 dark:text-white">
                {currentLanguageKeys["tech.card3.title"]}
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400 mt-2 mb-4 leading-relaxed">
                {currentLanguageKeys["tech.card3.desc"]}
              </p>
              <span className="inline-block px-3 py-1 bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 text-xs font-bold rounded-full">
                {currentLanguageKeys["tech.card3.badge"]}
              </span>
            </div>
          </div>
        </section>

        {/* 4. SOIL SENSOR SIMULATOR */}
        <SoilSensorSimulator
          onDiagnosticUpdate={(readings, diag) => {
            setSoilContext({ readings, diagnostic: diag });
          }}
          langKeys={currentLanguageKeys}
        />

        {/* 5. SUSTAINABILITY DASHBOARDS */}
        <SustainabilityDashboard
          langKeys={currentLanguageKeys}
          isHighContrast={settings.highContrast}
        />

        {/* 6. BLOCKCHAIN LEDGER & PAYMENTS */}
        <BlockchainLedger
          langKeys={currentLanguageKeys}
          isHighContrast={settings.highContrast}
        />

        {/* 7. PARANA STATE & IBGE QUERIES */}
        <ParanaGovernmentData langKeys={currentLanguageKeys} />

        {/* 8. BR-PORTUGUESE LIBRAS ACCESSIBILITY MODULE */}
        <section
          id="libras"
          className="p-6 bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl shadow-lg transition-all"
          aria-labelledby="libras-title"
        >
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">👋</span>
            <h2 id="libras-title" className="text-2xl font-bold text-slate-800 dark:text-white">
              {currentLanguageKeys["libras.title"]}
            </h2>
          </div>
          <p className="text-sm text-slate-500 dark:text-zinc-400 mb-6">
            {currentLanguageKeys["libras.subtitle"]}
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Seletor de Palavras do Glossário */}
            <div className="space-y-2.5">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1 block">
                Termos Agrícolas em LIBRAS
              </h3>
              <div className="flex flex-col gap-1.5 max-h-60 overflow-y-auto pr-1">
                {librasAgroGlossary.map((term) => (
                  <button
                    key={term.word}
                    onClick={() => setSelectedLibrasWord(term.word)}
                    className={`w-full text-left py-2 px-3.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                      selectedLibrasWord === term.word
                        ? "bg-green-700 text-white border-green-800"
                        : "bg-slate-50 dark:bg-zinc-850 text-slate-700 dark:text-zinc-300 border-slate-200 dark:border-zinc-800 hover:bg-slate-100"
                    }`}
                  >
                    {term.word}
                  </button>
                ))}
              </div>
            </div>

            {/* Demonstração do Sinal em LIBRAS */}
            {librasAgroGlossary.find((t) => t.word === selectedLibrasWord) && (
              <div className="lg:col-span-2 p-5 bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl flex flex-col justify-between">
                <div>
                  <span className="text-[10px] bg-green-100 dark:bg-green-950/40 text-green-800 dark:text-green-300 font-bold px-2 py-0.5 rounded uppercase font-mono tracking-wider">
                    {librasAgroGlossary.find((t) => t.word === selectedLibrasWord)?.category}
                  </span>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white mt-1.5">
                    Palavra: {selectedLibrasWord}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-zinc-400 mt-2">
                    <strong className="text-slate-700 dark:text-zinc-300">Significado:</strong>{" "}
                    {librasAgroGlossary.find((t) => t.word === selectedLibrasWord)?.description}
                  </p>
                </div>

                <div className="mt-4 p-4 bg-white dark:bg-zinc-900 border-2 border-dashed border-green-300 dark:border-zinc-800 rounded-lg">
                  <span className="font-bold text-xs text-green-800 dark:text-green-400 block mb-1">
                    Como fazer o sinal em LIBRAS (Representação Descritiva):
                  </span>
                  <p className="text-xs text-slate-700 dark:text-zinc-300 leading-relaxed">
                    {librasAgroGlossary.find((t) => t.word === selectedLibrasWord)?.signDescription}
                  </p>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* 9. CHAT AGRO-ADVISOR GPT */}
        <AgroGPTAdvisor
          langKeys={currentLanguageKeys}
          soilContext={soilContext}
        />
      </main>

      {/* 8. FOOTER */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 py-12 mt-16 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="flex justify-center items-center gap-2">
            <span className="text-lg font-black tracking-tight text-white">
              Agro<span className="text-green-500">Tech</span>
            </span>
            <span className="text-[10px] font-bold px-2.5 py-1 bg-slate-800 text-green-400 rounded-full font-mono uppercase border border-slate-700">
              Iretama Sustentável
            </span>
          </div>
          <p className="text-xs max-w-xl mx-auto leading-relaxed text-slate-400">
            {currentLanguageKeys["footer.rights"]} <br />
            Consultoria e fomento integrado aos órgãos públicos do estado do Paraná. Conectado ao DERAL, SEAB, IDR-PR e IBGE.
          </p>
          <div className="flex justify-center gap-6 text-[10px] text-slate-500 font-semibold pt-4 border-t border-slate-800">
            <span>Acessibilidade WCAG 2.1 Compilada</span>
            <span>VLibras Incorporado</span>
            <span>Blockchain AgroChain Certificada</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
