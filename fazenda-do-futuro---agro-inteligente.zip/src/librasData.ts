import { LibrasTerm } from "./types";

export const librasAgroGlossary: LibrasTerm[] = [
  {
    word: "Solo",
    category: "Agroecologia",
    description: "A camada superficial da Terra onde as plantas crescem. Essencial para a vida e nutrição.",
    signDescription: "Mão dominante aberta com a palma para baixo, faça movimentos circulares sobre o dorso da outra mão parada, representando a terra."
  },
  {
    word: "Sustentabilidade",
    category: "Princípios",
    description: "Capacidade de produzir alimentos hoje sem esgotar ou comprometer os recursos naturais das futuras gerações.",
    signDescription: "Forme a letra 'S' com a mão direita e faça um movimento circular subindo suavemente, seguido pelas duas mãos unidas em forma de concha protetora."
  },
  {
    word: "Tecnologia",
    category: "Inovação",
    description: "Uso de ferramentas avançadas, computadores, sensores ou robôs para ajudar nas atividades do campo.",
    signDescription: "Mão em 'Y' batendo suavemente no pulso oposto, simulando o acionamento de um dispositivo tecnológico ou relógio inteligente."
  },
  {
    word: "Iretama",
    category: "Geografia",
    description: "Município do Paraná conhecido por suas águas termais e rica produção de grãos e agricultura familiar.",
    signDescription: "Sinalize a letra 'I' seguida por um movimento em arco com as duas mãos descendo juntas, simulando águas termais ou colinas."
  },
  {
    word: "Agricultura de Precisão",
    category: "Inovação",
    description: "Método de plantio que usa sensores inteligentes para medir exatamente quanta água ou adubo cada planta precisa.",
    signDescription: "Indicadores e polegares de ambas as mãos formando pequenos pinos imaginários que tocam pontos específicos de uma superfície plana."
  },
  {
    word: "Drone",
    category: "Inovação",
    description: "Pequeno avião controlado por controle remoto que voa tirando fotos e jogando remédio natural nas plantações.",
    signDescription: "Mão aberta com dedos separados virada para baixo, imitando as hélices girando com giros circulares rápidos dos dedos indicador e médio."
  },
  {
    word: "Blockchain",
    category: "Finanças & Rastreabilidade",
    description: "Sistema digital super seguro que funciona como um livro de registros inviolável para garantir que o alimento é de boa origem.",
    signDescription: "As duas mãos com dedos entrelaçados em forma de corrente, afastando-se e juntando-se sequencialmente, simbolizando elos de blocos seguros."
  },
  {
    word: "IDR-Paraná",
    category: "Órgãos Públicos",
    description: "Instituto de Desenvolvimento Rural do Paraná, que ajuda produtores do estado com pesquisas e conselhos agrícolas.",
    signDescription: "Soletrar as letras I, D, R, e depois fazer o sinal de folha ou planta crescendo com a mão fechada abrindo os dedos para cima."
  }
];
