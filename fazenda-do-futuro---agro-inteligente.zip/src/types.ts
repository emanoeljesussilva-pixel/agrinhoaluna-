export interface CropPrice {
  name: string;
  price: number;
  change: string;
  trend: "up" | "down" | "stable";
}

export interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  precipitationProb: string;
  condition: string;
  windSpeed: string;
  climatologySource: string;
  bulletin: string;
}

export interface SEABIDRResponse {
  timestamp: string;
  weather: WeatherData;
  prices: {
    source: string;
    region: string;
    crops: CropPrice[];
  };
}

export interface IBGEIndicator {
  category: string;
  label: string;
  value: string;
  source: string;
}

export interface IBGEResponse {
  location: string;
  code: string;
  indicators: IBGEIndicator[];
  marketDemand: {
    summary: string;
    regionalTrend: string;
  };
}

export interface SoilSensorReadings {
  moisture: number; // %
  ph: number; // 0-14
  nitrogen: number; // mg/kg (N)
  phosphorus: number; // mg/kg (P)
  potassium: number; // mg/kg (K)
  temperature: number; // °C
}

export interface SoilDiagnostic {
  status: "ideal" | "warning" | "critical";
  recommendations: string[];
  suggestedCrops: string[];
}

export interface TraceableBatch {
  id: string;
  product: string;
  origin: string;
  producer: string;
  harvestDate: string;
  tonnes: number;
  carbonFootprint: string;
  pesticideReduction: string;
  waterEfficiency: string;
  soilPH: number;
  carCertificate: string;
  blockchainHash: string;
  status: string;
  ipfsMetadata: string;
}

export interface EnvironmentalReport {
  month: string;
  co2Captured: number; // toneladas
  waterSaved: number; // mil litros
  chemicalAvoided: number; // kg
  soilHealthIndex: number; // 0-100
  biodiversityScore: number; // 0-100
}

export interface AccessibilitySettings {
  fontSize: "sm" | "base" | "lg" | "xl";
  highContrast: boolean;
  dyslexicFont: boolean;
  readingLine: boolean;
  readingLineY: number;
  screenReaderActive: boolean;
  monochrome: boolean;
}

export type AppLanguage = "pt-BR" | "pt-Simple" | "en-US" | "es-ES";

export interface LibrasTerm {
  word: string;
  description: string;
  signDescription: string;
  category: string;
}
